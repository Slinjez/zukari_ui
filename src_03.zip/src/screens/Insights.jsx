import SparkLine from '../components/SparkLine';
import { Card, Label, Row } from '../components/ui';
import { DualMetricRows, SimpleBarChart, TimeInRangeStrip } from '../components/Charts';
import { AMBER, BLUE, BRAND, GREEN, MUTED, RED, TEXT } from '../constants/theme';
import {
  buildActivityTrend,
  buildCarbsGlucoseComparison,
  buildDailyGlucoseTrend,
  countRangeBuckets,
  generateLocalInsights,
} from '../utils/insights';

export default function InsightsScreen({ glucose, insulin, meals, exercises, stats, preferences }) {
  const glucoseUnit = preferences?.glucoseUnit || 'mmol/L';
  const targetMin = preferences?.targetMin ?? 3.9;
  const targetMax = preferences?.targetMax ?? 10;
  const smartInsights = generateLocalInsights({ glucose, insulin, meals, exercises, preferences });
  const rangeBuckets = countRangeBuckets(glucose, preferences);
  const glucoseTrend = buildDailyGlucoseTrend(glucose, 7);
  const activityTrend = buildActivityTrend(exercises, 7);
  const carbsGlucose = buildCarbsGlucoseComparison({ glucose, meals });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <header style={{ paddingTop: 12 }}>
        <div style={{ color: MUTED, fontSize: 13, fontWeight: 700 }}>Local analytics</div>
        <h1
          style={{
            color: TEXT,
            margin: '4px 0 0',
            fontSize: 25,
            letterSpacing: -0.8,
            lineHeight: 1.1,
          }}
        >
          Insights & charts
        </h1>
        <div style={{ color: MUTED, fontSize: 12, fontWeight: 650, marginTop: 4 }}>
          No API yet. Just local pattern spotting with zero cloud drama.
        </div>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {[
          { label: 'Average', value: stats.avgG, sub: glucoseUnit, tone: BRAND },
          { label: 'In range', value: `${stats.tir}%`, sub: `${targetMin}–${targetMax}`, tone: GREEN },
          { label: 'Low events', value: stats.low, sub: `< ${targetMin}`, tone: RED },
          { label: 'High events', value: stats.high, sub: `> ${targetMax}`, tone: AMBER },
        ].map((s) => (
          <Card key={s.label} compact>
            <div
              style={{
                color: s.tone,
                fontSize: 11,
                fontWeight: 900,
                textTransform: 'uppercase',
                letterSpacing: 1,
              }}
            >
              {s.label}
            </div>
            <div style={{ color: TEXT, fontSize: 26, fontWeight: 950, marginTop: 4 }}>{s.value}</div>
            <div style={{ color: MUTED, fontSize: 12, fontWeight: 700 }}>{s.sub}</div>
          </Card>
        ))}
      </div>

      <Card>
        <Label>Smart local insights</Label>
        <div style={{ display: 'grid', gap: 10 }}>
          {smartInsights.map((insight) => (
            <div
              key={`${insight.title}-${insight.body}`}
              style={{
                borderRadius: 17,
                border: `1px solid ${insight.tone}`,
                background: `${insight.tone}10`,
                padding: 13,
              }}
            >
              <div style={{ color: insight.tone, fontWeight: 950, fontSize: 14 }}>{insight.title}</div>
              <div style={{ color: MUTED, fontWeight: 700, fontSize: 12, marginTop: 5, lineHeight: 1.45 }}>
                {insight.body}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <Label>Time in range</Label>
        <TimeInRangeStrip low={rangeBuckets.low} range={rangeBuckets.range} high={rangeBuckets.high} />
      </Card>

      <Card>
        <Label>7-day glucose trend</Label>
        <SparkLine glucose={glucoseTrend.map((item) => ({ val: item.value })).filter((item) => item.val > 0)} height={118} />
        <div style={{ marginTop: 10 }}>
          <SimpleBarChart
            data={glucoseTrend}
            valueKey="value"
            labelKey="label"
            tone={BRAND}
            suffix={` ${glucoseUnit}`}
            emptyText="No glucose readings this week yet."
          />
        </div>
      </Card>

      <Card>
        <Label>Carbs vs glucose</Label>
        <DualMetricRows data={carbsGlucose} leftLabel="Carbs" rightLabel="Glucose" />
      </Card>

      <Card>
        <Label>Activity minutes this week</Label>
        <SimpleBarChart
          data={activityTrend}
          valueKey="value"
          labelKey="label"
          tone={BLUE}
          suffix=" min"
          emptyText="No activity logged this week. Even a walk to the fridge can start the chart."
        />
      </Card>

      <Card>
        <Label>Daily summary</Label>
        <Row title="Readings logged" subtitle="All stored readings" value={glucose.length} tone={BRAND} />
        <Row title="Target range" subtitle={glucoseUnit} value={`${targetMin}–${targetMax}`} tone={GREEN} />
        <Row title="Total carbs" subtitle="Today" value={`${stats.totalCarbs}g`} tone={AMBER} />
        <Row title="Insulin" subtitle="Today" value={`${stats.totalInsulin}u`} tone={BLUE} />
        <Row title="Activity" subtitle="Today" value={`${stats.activeMinutes} min`} tone={BLUE} />
      </Card>
    </div>
  );
}
