import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const REMINDER_IDS = {
  glucose: 7001,
  medication: 7002,
  insulin: 7003,
  bedtime: 7004,
};

const TEST_REMINDER_ID = 7099;
const CHANNEL_ID = 'zukari-daily-reminders';

const REMINDER_DEFINITIONS = [
  {
    key: 'glucose',
    enabledKey: 'reminderGlucose',
    timeKey: 'reminderGlucoseTime',
    id: REMINDER_IDS.glucose,
    title: 'Glucose check',
    body: 'Boss, umecheck sugar ama tunaishi by vibes today?',
  },
  {
    key: 'medication',
    enabledKey: 'reminderMedication',
    timeKey: 'reminderMedicationTime',
    id: REMINDER_IDS.medication,
    title: 'Medication time',
    body: 'Medication time. Future you is already clapping.',
  },
  {
    key: 'insulin',
    enabledKey: 'reminderInsulin',
    timeKey: 'reminderInsulinTime',
    id: REMINDER_IDS.insulin,
    title: 'Insulin log check',
    body: 'Quick insulin log check. Zukari is not judging, just monitoring with eyebrows raised.',
  },
  {
    key: 'bedtime',
    enabledKey: 'reminderBedtime',
    timeKey: 'reminderBedtimeTime',
    id: REMINDER_IDS.bedtime,
    title: 'Bedtime sugar check',
    body: 'Bedtime sugar check. Let us not let the night shift surprise us.',
  },
];

function isNativePlatform() {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

function parseTime(value, fallback = '09:00') {
  const source = /^\d{2}:\d{2}$/.test(String(value || '')) ? value : fallback;
  const [hourText, minuteText] = source.split(':');
  const hour = Number.parseInt(hourText, 10);
  const minute = Number.parseInt(minuteText, 10);

  if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
    return { hour: 9, minute: 0 };
  }

  return { hour, minute };
}

function permissionIsGranted(status) {
  return status?.display === 'granted';
}

async function ensureAndroidChannel() {
  if (!isNativePlatform() || Capacitor.getPlatform() !== 'android') {
    return;
  }

  try {
    await LocalNotifications.createChannel({
      id: CHANNEL_ID,
      name: 'Zukari reminders',
      description: 'Daily glucose, insulin, medication and bedtime reminders.',
      importance: 4,
      visibility: 1,
      sound: 'default',
      vibration: true,
    });
  } catch (error) {
    console.warn('Could not create Zukari notification channel', error);
  }
}

async function checkPermission() {
  if (!isNativePlatform()) {
    return {
      display: 'web',
      message: 'Local notifications are available in the Android/iOS app build. Web preview cannot schedule real device reminders.',
    };
  }

  try {
    return await LocalNotifications.checkPermissions();
  } catch (error) {
    return {
      display: 'error',
      message: error?.message || 'Could not check notification permission.',
    };
  }
}

async function requestPermission() {
  if (!isNativePlatform()) {
    return {
      display: 'web',
      message: 'Open the Android/iOS app build to allow local reminders. Browser preview is just rehearsing the speech.',
    };
  }

  try {
    const current = await LocalNotifications.checkPermissions();

    if (permissionIsGranted(current)) {
      return current;
    }

    return LocalNotifications.requestPermissions();
  } catch (error) {
    return {
      display: 'error',
      message: error?.message || 'Could not request notification permission.',
    };
  }
}

async function cancelDailyReminders() {
  if (!isNativePlatform()) {
    return { cancelled: false, reason: 'web' };
  }

  await LocalNotifications.cancel({
    notifications: Object.values(REMINDER_IDS).map((id) => ({ id })),
  });

  return { cancelled: true };
}

function buildNotifications(preferences = {}) {
  return REMINDER_DEFINITIONS
    .filter((definition) => Boolean(preferences?.[definition.enabledKey]))
    .map((definition) => {
      const { hour, minute } = parseTime(preferences?.[definition.timeKey]);

      return {
        id: definition.id,
        title: definition.title,
        body: definition.body,
        schedule: {
          on: { hour, minute },
          repeats: true,
          allowWhileIdle: true,
        },
        channelId: CHANNEL_ID,
      };
    });
}

async function syncReminders(preferences = {}) {
  const permission = await checkPermission();

  if (!isNativePlatform()) {
    return {
      ok: false,
      platform: 'web',
      permission,
      scheduled: 0,
      message: permission.message,
    };
  }

  if (!permissionIsGranted(permission)) {
    await cancelDailyReminders();

    return {
      ok: false,
      platform: Capacitor.getPlatform(),
      permission,
      scheduled: 0,
      message: 'Notification permission is not granted yet. Tap Enable reminders first.',
    };
  }

  await ensureAndroidChannel();
  await cancelDailyReminders();

  const notifications = buildNotifications(preferences);

  if (notifications.length > 0) {
    await LocalNotifications.schedule({ notifications });
  }

  return {
    ok: true,
    platform: Capacitor.getPlatform(),
    permission,
    scheduled: notifications.length,
    message: notifications.length
      ? `${notifications.length} daily reminder${notifications.length === 1 ? '' : 's'} scheduled.`
      : 'All reminder switches are off. Zukari will remain respectfully quiet.',
  };
}

async function enableAndSync(preferences = {}) {
  const permission = await requestPermission();

  if (!permissionIsGranted(permission)) {
    return {
      ok: false,
      permission,
      scheduled: 0,
      message: permission.message || 'Notification permission was not granted.',
    };
  }

  return syncReminders(preferences);
}

async function sendTestReminder() {
  const permission = await requestPermission();

  if (!isNativePlatform()) {
    return {
      ok: false,
      permission,
      message: permission.message,
    };
  }

  if (!permissionIsGranted(permission)) {
    return {
      ok: false,
      permission,
      message: 'Notification permission was not granted, so the test reminder stayed in the garage.',
    };
  }

  await ensureAndroidChannel();
  await LocalNotifications.schedule({
    notifications: [
      {
        id: TEST_REMINDER_ID,
        title: 'Zukari test reminder',
        body: 'Boss, this is the test nudge. The reminder engine has entered the chat.',
        schedule: { at: new Date(Date.now() + 4000), allowWhileIdle: true },
        channelId: CHANNEL_ID,
      },
    ],
  });

  return {
    ok: true,
    permission,
    message: 'Test reminder scheduled. Give it a few seconds to knock politely.',
  };
}

async function getStatus() {
  const permission = await checkPermission();

  if (!isNativePlatform() || !permissionIsGranted(permission)) {
    return {
      platform: isNativePlatform() ? Capacitor.getPlatform() : 'web',
      permission,
      pendingCount: 0,
    };
  }

  try {
    const pending = await LocalNotifications.getPending();
    const reminderIds = new Set(Object.values(REMINDER_IDS));
    const pendingCount = (pending?.notifications || []).filter((item) => reminderIds.has(item.id)).length;

    return {
      platform: Capacitor.getPlatform(),
      permission,
      pendingCount,
    };
  } catch (error) {
    return {
      platform: Capacitor.getPlatform(),
      permission,
      pendingCount: 0,
      error: error?.message || 'Could not read pending reminders.',
    };
  }
}

export const reminderService = {
  checkPermission,
  requestPermission,
  enableAndSync,
  syncReminders,
  cancelDailyReminders,
  sendTestReminder,
  getStatus,
  buildNotifications,
};
