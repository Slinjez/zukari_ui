import logoSrc from '../assets/zukari-logo.png';
import { BORDER } from '../constants/theme';

export default function BrandLogo({ size = 72, compact = false, style = {} }) {
  const width = compact ? size * 1.45 : size;

  return (
    <img
      src={logoSrc}
      alt="Zukari logo"
      style={{
        width,
        height: size,
        objectFit: 'contain',
        display: 'block',
        borderRadius: compact ? 14 : 22,
        background: '#fff6e8',
        border: `1px solid ${BORDER}`,
        boxShadow: compact ? '0 8px 20px rgba(43,22,9,.08)' : '0 18px 44px rgba(43,22,9,.16)',
        ...style,
      }}
    />
  );
}
