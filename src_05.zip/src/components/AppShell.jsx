import { Activity } from 'lucide-react';
import BrandLogo from './BrandLogo';
import { BG, BORDER, BRAND, BRAND_DARK, BRAND_SOFT, MUTED, TEXT } from '../constants/theme';
import { NAV } from '../constants/data';

export default function AppShell({ screen, setScreen, children, glucoseUnit = 'mmol/L', name = 'Bo$$' }) {
  const current = NAV.find((n) => n.id === screen);
  const firstName = String(name || 'Bo$$').split(' ')[0];

  return (
    <div
      style={{
        background: BG,
        minHeight: '100vh',
        width: '100%',
        color: TEXT,
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        paddingBottom: 88,
        overflowX: 'hidden',
      }}
    >
      <div
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 10,
          background: 'rgba(247,239,231,.94)',
          backdropFilter: 'blur(18px)',
          borderBottom: `1px solid ${BORDER}`,
          padding: '14px 18px 12px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
            <BrandLogo
              size={42}
              compact
              style={{
                flexShrink: 0,
                borderRadius: 13,
                boxShadow: '0 8px 20px rgba(43,22,9,.08)',
              }}
            />
            <div style={{ minWidth: 0 }}>
              <div style={{ color: BRAND, fontWeight: 950, fontSize: 13, letterSpacing: 2.4 }}>ZUKARI</div>
              <div style={{ color: MUTED, fontSize: 12, fontWeight: 700, marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {current?.label || 'Dashboard'} · {firstName}
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              color: BRAND_DARK,
              background: BRAND_SOFT,
              border: `1px solid ${BORDER}`,
              padding: '8px 11px',
              borderRadius: 999,
              fontWeight: 900,
              fontSize: 12,
            }}
          >
            <Activity size={15} /> {glucoseUnit}
          </div>
        </div>
      </div>

      <main style={{ padding: '0 16px 18px', maxWidth: 560, margin: '0 auto' }}>{children}</main>

      <nav
        style={{
          position: 'fixed',
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 20,
          background: 'rgba(255,250,245,.96)',
          backdropFilter: 'blur(18px)',
          borderTop: `1px solid ${BORDER}`,
          padding: '8px 8px calc(8px + env(safe-area-inset-bottom))',
        }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${NAV.length}, minmax(0, 1fr))`,
            gap: 4,
            maxWidth: 560,
            margin: '0 auto',
          }}
        >
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = screen === n.id;

            return (
              <button
                key={n.id}
                onClick={() => setScreen(n.id)}
                style={{
                  border: 'none',
                  background: active ? BRAND_SOFT : 'transparent',
                  color: active ? BRAND_DARK : MUTED,
                  borderRadius: 15,
                  minHeight: 54,
                  minWidth: 0,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 4,
                  cursor: 'pointer',
                  fontWeight: active ? 950 : 750,
                  fontSize: 9,
                }}
              >
                <Icon size={18} strokeWidth={active ? 3 : 2.25} />
                <span
                  style={{
                    display: 'block',
                    maxWidth: '100%',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {n.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
