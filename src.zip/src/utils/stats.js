export function getStats({ glucose, insulin, meals, exercises }) {
  const latestG = glucose[glucose.length - 1];
  const totalCarbs = meals.reduce((s, m) => s + Number(m.carbs), 0);
  const totalInsulin = insulin.reduce((s, i) => s + Number(i.dose), 0);
  const avgG = (glucose.reduce((s, g) => s + Number(g.val), 0) / glucose.length).toFixed(1);
  const inRange = glucose.filter((g) => g.val >= 3.9 && g.val <= 10.0).length;
  const tir = Math.round((inRange / glucose.length) * 100);
  const activeMinutes = exercises.reduce((s, e) => s + Number(e.duration), 0);
  const novorapid = insulin.filter((i) => i.type === 'Novorapid').reduce((s, i) => s + Number(i.dose), 0);
  const lantus = insulin.filter((i) => i.type === 'Lantus').reduce((s, i) => s + Number(i.dose), 0);
  const low = glucose.filter((g) => g.val < 3.9).length;
  const high = glucose.filter((g) => g.val > 10.0).length;
  return { latestG, totalCarbs, totalInsulin, avgG, tir, activeMinutes, novorapid, lantus, low, high };
}

export function projectedHbA1c(avgMmol) {
  const avg = Number(avgMmol);

  if (!Number.isFinite(avg) || avg <= 0) {
    return null;
  }

  return ((avg + 2.59) / 1.59).toFixed(1);
}