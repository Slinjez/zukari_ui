import { useState } from 'react';
import AppShell from './components/AppShell';
import Onboarding from './screens/Onboarding';
import HomeScreen from './screens/Home';
import GlucoseScreen from './screens/Glucose';
import InsulinScreen from './screens/Insulin';
import MealsScreen from './screens/Meals';
import ExerciseScreen from './screens/Exercise';
import InsightsScreen from './screens/Insights';
import { getStats } from './utils/stats';

export default function App() {
  const [screen, setScreen] = useState('home');
  const [glucose, setGlucose] = useState([
    { val: 5.2, time: '07:30 AM', note: 'Fasting' },
    { val: 7.8, time: '10:00 AM', note: 'Mid morning' },
    { val: 8.8, time: '12:45 PM', note: 'After lunch' },
    { val: 6.1, time: '03:00 PM', note: 'Afternoon' },
    { val: 4.9, time: '06:00 PM', note: 'Before dinner' },
    { val: 7.2, time: '08:30 PM', note: 'After dinner' },
    { val: 6.5, time: '10:00 PM', note: 'Bedtime' },
  ]);
  const [insulin, setInsulin] = useState([
    { type: 'Lantus', dose: 20, time: '08:00 AM' },
    { type: 'Novorapid', dose: 6, time: '12:30 PM' },
  ]);
  const [meals, setMeals] = useState([
    { name: 'Githeri', carbs: 45, time: '08:15 AM' },
    { name: 'Rice', carbs: 52, time: '01:00 PM' },
  ]);
  const [exercises, setExercises] = useState([{ type: 'Walking', duration: 30, time: '07:00 AM' }]);

  const [gVal, setGVal] = useState('');
  const [gNote, setGNote] = useState('');
  const [iType, setIType] = useState('Novorapid');
  const [iDose, setIDose] = useState('');
  const [mName, setMName] = useState('');
  const [mCarbs, setMCarbs] = useState('');
  const [eType, setEType] = useState('Walking');
  const [eDur, setEDur] = useState('');
  const [welcomeStep, setWelcomeStep] = useState(0);
  const [hasSeenWelcome, setHasSeenWelcome] = useState(() => {
    try { return localStorage.getItem('zukari_welcome_done') === 'yes'; }
    catch { return false; }
  });

  const finishWelcome = () => {
    try { localStorage.setItem('zukari_welcome_done', 'yes'); } catch { /* ignore */ }
    setHasSeenWelcome(true);
  };

  const stats = getStats({ glucose, insulin, meals, exercises });

  if (!hasSeenWelcome) {
    return <Onboarding welcomeStep={welcomeStep} setWelcomeStep={setWelcomeStep} finishWelcome={finishWelcome} tir={stats.tir} />;
  }

  const common = { stats };
  const screens = {
    home: <HomeScreen {...common} glucose={glucose} setScreen={setScreen} />,
    blood_sugar: <GlucoseScreen glucose={glucose} setGlucose={setGlucose} form={{ gVal, setGVal, gNote, setGNote }} />,
    insulin: <InsulinScreen {...common} insulin={insulin} setInsulin={setInsulin} form={{ iType, setIType, iDose, setIDose }} />,
    meals: <MealsScreen meals={meals} setMeals={setMeals} form={{ mName, setMName, mCarbs, setMCarbs }} />,
    exercise: <ExerciseScreen exercises={exercises} setExercises={setExercises} form={{ eType, setEType, eDur, setEDur }} />,
    insights: <InsightsScreen {...common} glucose={glucose} />,
  };

  return <AppShell screen={screen} setScreen={setScreen}>{screens[screen]}</AppShell>;
}
