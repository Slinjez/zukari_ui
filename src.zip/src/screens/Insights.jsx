import SparkLine from "../components/SparkLine";
import { Card, Label, Row } from "../components/ui";
import {
  AMBER,
  BLUE,
  BRAND,
  GREEN,
  MUTED,
  RED,
  TEXT,
} from "../constants/theme";

export default function InsightsScreen({ glucose, stats }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {[
          { label: "Average", value: stats.avgG, sub: "mmol/L", tone: BRAND },
          {
            label: "In range",
            value: `${stats.tir}%`,
            sub: "3.9–10.0",
            tone: GREEN,
          },
          { label: "Low events", value: stats.low, sub: "today", tone: RED },
          {
            label: "High events",
            value: stats.high,
            sub: "today",
            tone: AMBER,
          },
        ].map((s) => (
          <Card key={s.label} compact>
            <div
              style={{
                color: s.tone,
                fontSize: 11,
                fontWeight: 900,
                textTransform: "uppercase",
                letterSpacing: 1,
              }}
            >
              {s.label}
            </div>
            <div
              style={{
                color: TEXT,
                fontSize: 26,
                fontWeight: 950,
                marginTop: 4,
              }}
            >
              {s.value}
            </div>
            <div style={{ color: MUTED, fontSize: 12, fontWeight: 700 }}>
              {s.sub}
            </div>
          </Card>
        ))}
      </div>
      <Card>
        <Label>Glucose trend</Label>
        <SparkLine glucose={glucose} height={118} />
      </Card>
      <Card>
        <Label>Daily summary</Label>
        <Row
          title="Readings logged"
          subtitle="Today"
          value={glucose.length}
          tone={BRAND}
        />
        <Row
          title="Total carbs"
          subtitle="Food entries"
          value={`${stats.totalCarbs}g`}
          tone={AMBER}
        />
        <Row
          title="Novorapid"
          subtitle="Fast-acting"
          value={`${stats.novorapid}u`}
          tone={BLUE}
        />
        <Row
          title="Lantus"
          subtitle="Long-acting"
          value={`${stats.lantus}u`}
          tone={BRAND}
        />
        <Row
          title="Activity"
          subtitle="Active minutes"
          value={`${stats.activeMinutes} min`}
          tone={BLUE}
        />
      </Card>
    </div>
  );
}
