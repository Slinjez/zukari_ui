import {
  BarChart3,
  ChevronRight,
  Droplet,
  Salad,
  ShieldCheck,
  Syringe,
} from "lucide-react";
import SparkLine from "../components/SparkLine";
import { Card } from "../components/ui";
import {
  AMBER,
  BLUE,
  BRAND,
  BRAND_DARK,
  BRAND_SOFT,
  BORDER, 
  MUTED,
  RED,
  TEXT,
  statusOf,
} from "../constants/theme";

function QuickAction({ icon: Icon, title, subtitle, tone, target, setScreen }) {
  return (
    <button
      onClick={() => setScreen(target)}
      style={{
        background: "#fffaf5",
        border: `1px solid ${BORDER}`,
        borderRadius: 18,
        padding: 14,
        textAlign: "left",
        minHeight: 94,
        cursor: "pointer",
        boxShadow: "0 8px 24px rgba(79,54,0,.05)",
      }}
    >
      <div
        style={{
          width: 36,
          height: 36,
          borderRadius: 12,
          display: "grid",
          placeItems: "center",
          color: tone,
          background: `${tone}14`,
          marginBottom: 10,
        }}
      >
        <Icon size={20} strokeWidth={2.5} />
      </div>
      <div style={{ color: TEXT, fontWeight: 900, fontSize: 14 }}>{title}</div>
      <div
        style={{ color: MUTED, fontWeight: 600, fontSize: 11, marginTop: 2 }}
      >
        {subtitle}
      </div>
    </button>
  );
}

export default function HomeScreen({ glucose, stats, setScreen }) {
  const status = statusOf(stats.latestG?.val || 5.5);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <header style={{ paddingTop: 12 }}>
        <div style={{ color: MUTED, fontSize: 13, fontWeight: 700 }}>
          Hello, Bo$$
        </div>
        <h1
          style={{
            color: TEXT,
            margin: "4px 0 0",
            fontSize: 25,
            letterSpacing: -0.8,
            lineHeight: 1.1,
          }}
        >
          Glucose dashboard
        </h1>
      </header>
      <Card style={{ padding: 0, overflow: "hidden" }}>
        <div
          style={{
            padding: 18,
            background: `linear-gradient(135deg, ${BRAND_DARK}, ${BRAND})`,
            color: "#fff",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 12,
            }}
          >
            <div>
              <div
                style={{
                  opacity: 0.72,
                  fontSize: 11,
                  fontWeight: 900,
                  letterSpacing: 1.4,
                  textTransform: "uppercase",
                }}
              >
                Latest reading
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: 8,
                  marginTop: 8,
                }}
              >
                <span
                  style={{ fontSize: 54, fontWeight: 950, letterSpacing: -2 }}
                >
                  {stats.latestG.val.toFixed(1)}
                </span>
                <span style={{ opacity: 0.75, fontWeight: 700 }}>mmol/L</span>
              </div>
              <div style={{ opacity: 0.78, fontSize: 12, fontWeight: 700 }}>
                Updated {stats.latestG.time}
              </div>
            </div>
            <span
              style={{
                background: "rgba(255,255,255,.16)",
                border: "1px solid rgba(255,255,255,.22)",
                borderRadius: 999,
                padding: "8px 12px",
                fontWeight: 900,
                fontSize: 12,
              }}
            >
              {status.label}
            </span>
          </div>
        </div>
        <div style={{ padding: "14px 18px 18px" }}>
          <SparkLine glucose={glucose} />
          <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
            <div
              style={{
                flex: 1,
                background: BRAND_SOFT,
                borderRadius: 16,
                padding: 12,
              }}
            >
              <div
                style={{
                  color: BRAND,
                  fontSize: 11,
                  fontWeight: 900,
                  textTransform: "uppercase",
                }}
              >
                Avg
              </div>
              <div style={{ color: TEXT, fontSize: 22, fontWeight: 950 }}>
                {stats.avgG}
              </div>
            </div>

            <div
              style={{
                flex: 1,
                background: "#e6d2bd",
                borderRadius: 16,
                padding: 12,
              }}
            >
              <div
                style={{
                  color: "#5a3218",
                  fontSize: 11,
                  fontWeight: 800,
                  textTransform: "uppercase",
                }}
              >
                Projected HbA1c
              </div>

              <div style={{ color: TEXT, fontSize: 22, fontWeight: 850 }}>
                {stats.hba1c ? `${stats.hba1c}%` : "--"}
              </div>
            </div>
          </div>
        </div>
      </Card>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <QuickAction
          icon={Droplet}
          title="Log glucose"
          subtitle="Reading"
          tone={BLUE}
          target="blood_sugar"
          setScreen={setScreen}
        />
        <QuickAction
          icon={Salad}
          title="Log food"
          subtitle={`${stats.totalCarbs}g carbs`}
          tone={AMBER}
          target="meals"
          setScreen={setScreen}
        />
        <QuickAction
          icon={Syringe}
          title="Insulin"
          subtitle={`${stats.totalInsulin}u today`}
          tone={RED}
          target="insulin"
          setScreen={setScreen}
        />
        <QuickAction
          icon={BarChart3}
          title="Reports"
          subtitle="Trends"
          tone={BRAND}
          target="insights"
          setScreen={setScreen}
        />
      </div>
      <Card compact>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div
            style={{
              background: status.bg,
              color: status.tone,
              width: 42,
              height: 42,
              borderRadius: 15,
              display: "grid",
              placeItems: "center",
            }}
          >
            <ShieldCheck size={22} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ color: TEXT, fontWeight: 900, fontSize: 14 }}>
              {status.advice}
            </div>
            <div style={{ color: MUTED, fontSize: 12, marginTop: 2 }}>
              Last note: {stats.latestG.note}
            </div>
          </div>
          <ChevronRight size={20} color={MUTED} />
        </div>
      </Card>
    </div>
  );
}
