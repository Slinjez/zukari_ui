import { Card, Input, Label, PrimaryButton, Row } from '../components/ui';
import { BLUE, BORDER, MUTED } from '../constants/theme';
import { formatTime } from '../utils/time';

export default function ExerciseScreen({ exercises, setExercises, form }) {
  const { eType, setEType, eDur, setEDur } = form;
  return <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
    <Card><Label>Log activity</Label><div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>{['Walking', 'Running', 'Cycling', 'Swimming', 'Gym'].map((t) => <button key={t} onClick={() => setEType(t)} style={{ padding: '10px 14px', borderRadius: 999, border: `1px solid ${eType === t ? BLUE : BORDER}`, background: eType === t ? '#eef5ff' : '#fbfaf7', color: eType === t ? BLUE : MUTED, fontWeight: 850, cursor: 'pointer' }}>{t}</button>)}</div><div style={{ display: 'grid', gap: 10 }}><Input value={eDur} onChange={setEDur} placeholder="Duration in minutes" /><PrimaryButton color={BLUE} onClick={() => { if (!eDur) return; setExercises([...exercises, { type: eType, duration: Number(eDur), time: formatTime() }]); setEDur(''); }}>Log activity</PrimaryButton></div></Card>
    <Card><Label>Activity log</Label>{[...exercises].reverse().map((e, i, arr) => <div key={`${e.type}-${i}`} style={{ borderBottom: i < arr.length - 1 ? `1px solid ${BORDER}` : 'none' }}><Row title={e.type} subtitle={e.time} value={`${e.duration} min`} tone={BLUE} /></div>)}</Card>
  </div>;
}
