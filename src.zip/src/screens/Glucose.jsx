import { Card, Input, Label, PrimaryButton, Row } from '../components/ui';
import { AMBER, BLUE, BORDER, GREEN, RED, statusOf } from '../constants/theme';
import { formatTime } from '../utils/time';

export default function GlucoseScreen({ glucose, setGlucose, form }) {
  const { gVal, setGVal, gNote, setGNote } = form;
  return <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
    <Card><Label>Log blood sugar</Label><div style={{ display: 'grid', gap: 10 }}><Input value={gVal} onChange={setGVal} placeholder="e.g. 6.4" step="0.1" /><Input value={gNote} onChange={setGNote} type="text" placeholder="Note, e.g. Before breakfast" /><PrimaryButton color={BLUE} onClick={() => { if (!gVal) return; setGlucose([...glucose, { val: parseFloat(gVal), time: formatTime(), note: gNote || 'Manual' }]); setGVal(''); setGNote(''); }}>Log reading</PrimaryButton></div></Card>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>{[{ label: 'Low', range: '< 3.9', tone: RED, bg: '#f4e1dc' }, { label: 'Range', range: '3.9–10', tone: GREEN, bg: '#edf0df' }, { label: 'High', range: '> 10', tone: AMBER, bg: '#f6e8d3' }].map((x) => <div key={x.label} style={{ background: x.bg, borderRadius: 16, padding: 12, textAlign: 'center' }}><div style={{ color: x.tone, fontWeight: 950, fontSize: 13 }}>{x.range}</div><div style={{ color: x.tone, opacity: .8, fontWeight: 800, fontSize: 11 }}>{x.label}</div></div>)}</div>
    <Card><Label>Reading history</Label>{[...glucose].reverse().map((g, i, arr) => { const st = statusOf(g.val); return <div key={`${g.time}-${i}`} style={{ borderBottom: i < arr.length - 1 ? `1px solid ${BORDER}` : 'none' }}><Row title={g.note} subtitle={g.time} value={g.val.toFixed(1)} tone={st.tone} badge={st.label} /></div>; })}</Card>
  </div>;
}
