import { Card, Input, Label, PrimaryButton, Row } from "../components/ui";
import {
  BLUE,
  BORDER,
  BRAND,
  BRAND_SOFT,
  MUTED,
  TEXT,
} from "../constants/theme";
import { formatTime } from "../utils/time";

export default function InsulinScreen({ insulin, setInsulin, stats, form }) {
  const { iType, setIType, iDose, setIDose } = form;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Card>
        <Label>Log insulin dose</Label>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 10,
            marginBottom: 10,
          }}
        >
          {["Novorapid", "Lantus"].map((t) => {
            const selected = iType === t;
            const tone = t === "Novorapid" ? BLUE : BRAND;
            return (
              <button
                key={t}
                onClick={() => setIType(t)}
                style={{
                  height: 46,
                  border: `1px solid ${selected ? tone : BORDER}`,
                  background: selected ? `${tone}14` : "#fbfaf7",
                  color: selected ? tone : MUTED,
                  borderRadius: 14,
                  fontWeight: 900,
                  cursor: "pointer",
                }}
              >
                {t}
              </button>
            );
          })}
        </div>
        <div style={{ display: "grid", gap: 10 }}>
          <Input
            value={iDose}
            onChange={setIDose}
            placeholder="Units, e.g. 8"
          />
          <PrimaryButton
            color={iType === "Novorapid" ? BLUE : BRAND}
            onClick={() => {
              if (!iDose) return;
              setInsulin([
                ...insulin,
                { type: iType, dose: Number(iDose), time: formatTime() },
              ]);
              setIDose("");
            }}
          >
            Log {iType} dose
          </PrimaryButton>
        </div>
      </Card>
      <Card>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Label>Today’s doses</Label>
          <span
            style={{
              color: BRAND,
              background: BRAND_SOFT,
              padding: "6px 10px",
              borderRadius: 999,
              fontSize: 12,
              fontWeight: 900,
            }}
          >
            {stats.totalInsulin}u total
          </span>
        </div>
        {[...insulin].reverse().map((d, i, arr) => {
          const tone = d.type === "Novorapid" ? BLUE : BRAND;
          return (
            <div
              key={`${d.type}-${i}`}
              style={{
                borderBottom:
                  i < arr.length - 1 ? `1px solid ${BORDER}` : "none",
              }}
            >
              <Row
                title={d.type}
                subtitle={d.time}
                value={`${d.dose}u`}
                tone={tone}
                badge={d.type === "Novorapid" ? "Fast" : "Long"}
              />
            </div>
          );
        })}
      </Card>
    </div>
  );
}
