import { Card, Input, Label, PrimaryButton, Row } from "../components/ui";
import { AMBER, BORDER, TEXT } from "../constants/theme";
import { MEAL_TEMPLATES } from "../constants/data";
import { formatTime } from "../utils/time";

export default function MealsScreen({ meals, setMeals, form }) {
  const { mName, setMName, mCarbs, setMCarbs } = form;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Card>
        <Label>Quick add</Label>
        <div style={{ display: "grid", gap: 10 }}>
          {MEAL_TEMPLATES.map((t) => (
            <button
              key={t.name}
              onClick={() => {
                setMName(t.name);
                setMCarbs(String(t.carbs));
              }}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "14px 16px",
                background: mName === t.name ? "#fff6e5" : "#fbfaf7",
                border: `1px solid ${mName === t.name ? AMBER : BORDER}`,
                borderRadius: 16,
                cursor: "pointer",
                color: TEXT,
              }}
            >
              <span style={{ fontWeight: 900 }}>{t.name}</span>
              <span style={{ color: AMBER, fontWeight: 900 }}>
                {t.carbs}g carbs
              </span>
            </button>
          ))}
        </div>
      </Card>
      <Card>
        <Label>Log meal</Label>
        <div style={{ display: "grid", gap: 10 }}>
          <Input
            value={mName}
            onChange={setMName}
            type="text"
            placeholder="Meal name"
          />
          <Input
            value={mCarbs}
            onChange={setMCarbs}
            placeholder="Carbs in grams"
          />
          <PrimaryButton
            color={AMBER}
            onClick={() => {
              if (!mName || !mCarbs) return;
              setMeals([
                ...meals,
                { name: mName, carbs: Number(mCarbs), time: formatTime() },
              ]);
              setMName("");
              setMCarbs("");
            }}
          >
            Log meal
          </PrimaryButton>
        </div>
      </Card>
      <Card>
        <Label>Today’s food</Label>
        {[...meals].reverse().map((m, i, arr) => (
          <div
            key={`${m.name}-${i}`}
            style={{
              borderBottom: i < arr.length - 1 ? `1px solid ${BORDER}` : "none",
            }}
          >
            <Row
              title={m.name}
              subtitle={m.time}
              value={`${m.carbs}g`}
              tone={AMBER}
            />
          </div>
        ))}
      </Card>
    </div>
  );
}
