import { Activity } from 'lucide-react';
import { BG, BORDER, BRAND, BRAND_DARK, BRAND_SOFT, MUTED, TEXT } from '../constants/theme';
import { NAV } from '../constants/data';

export default function AppShell({ screen, setScreen, children }) {
  const current = NAV.find((n) => n.id === screen);
  return <div style={{ background: BG, minHeight: '100vh', width: '100%', color: TEXT, fontFamily: "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", paddingBottom: 86, overflowX: 'hidden' }}>
    <div style={{ position: 'sticky', top: 0, zIndex: 10, background: 'rgba(247,239,231,.94)', backdropFilter: 'blur(18px)', borderBottom: `1px solid ${BORDER}`, padding: '14px 18px 12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div><div style={{ color: BRAND, fontWeight: 950, fontSize: 13, letterSpacing: 2.4 }}>ZUKARI</div><div style={{ color: MUTED, fontSize: 12, fontWeight: 700, marginTop: 2 }}>{current?.label || 'Dashboard'}</div></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: BRAND_DARK, background: BRAND_SOFT, border: `1px solid ${BORDER}`, padding: '8px 11px', borderRadius: 999, fontWeight: 900, fontSize: 12 }}><Activity size={15} /> mmol/L</div>
      </div>
    </div>
    <main style={{ padding: '0 16px 18px', maxWidth: 560, margin: '0 auto' }}>{children}</main>
    <nav style={{ position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 20, background: 'rgba(255,250,245,.96)', backdropFilter: 'blur(18px)', borderTop: `1px solid ${BORDER}`, padding: '8px 8px calc(8px + env(safe-area-inset-bottom))' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 4, maxWidth: 560, margin: '0 auto' }}>{NAV.map((n) => { const Icon = n.icon; const active = screen === n.id; return <button key={n.id} onClick={() => setScreen(n.id)} style={{ border: 'none', background: active ? BRAND_SOFT : 'transparent', color: active ? BRAND_DARK : MUTED, borderRadius: 16, minHeight: 54, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, cursor: 'pointer', fontWeight: active ? 950 : 750, fontSize: 10 }}><Icon size={19} strokeWidth={active ? 3 : 2.25} /><span>{n.label}</span></button>; })}</div>
    </nav>
  </div>;
}
