// src/app/services/zukari-storage.service.ts

import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';

export type SyncStatus = 'synced' | 'unsynced';

export interface BaseLog {
  id: string;
  createdAt: string;
  updatedAt: string;
  syncStatus: SyncStatus;
}

export interface GlucoseLog extends BaseLog {
  value: number;
  unit: 'mmol/L' | 'mg/dL';
  context?: 'fasting' | 'before_meal' | 'after_meal' | 'bedtime' | 'random';
  notes?: string;
}

export interface InsulinLog extends BaseLog {
  insulinType: string;
  units: number;
  notes?: string;
}

export interface MealLog extends BaseLog {
  mealName: string;
  carbsEstimate?: number;
  caloriesEstimate?: number;
  notes?: string;
}

export interface ActivityLog extends BaseLog {
  activityName: string;
  durationMinutes?: number;
  notes?: string;
}

export interface UserPreferences {
  welcomeCompleted: boolean;
  name?: string;
  diabetesType?: 'type_1' | 'type_2' | 'gestational' | 'other';
  glucoseUnit: 'mmol/L' | 'mg/dL';
  targetMin: number;
  targetMax: number;
  darkMode: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class ZukariStorageService {
  private readonly keys = {
    glucoseLogs: 'zukari_glucose_logs',
    insulinLogs: 'zukari_insulin_logs',
    mealLogs: 'zukari_meal_logs',
    activityLogs: 'zukari_activity_logs',
    preferences: 'zukari_user_preferences',
  };

  private createId(): string {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }

  private now(): string {
    return new Date().toISOString();
  }

  private async getJson<T>(key: string, fallback: T): Promise<T> {
    const result = await Preferences.get({ key });

    if (!result.value) {
      return fallback;
    }

    try {
      return JSON.parse(result.value) as T;
    } catch {
      return fallback;
    }
  }

  private async setJson<T>(key: string, value: T): Promise<void> {
    await Preferences.set({
      key,
      value: JSON.stringify(value),
    });
  }

  async getGlucoseLogs(): Promise<GlucoseLog[]> {
    return this.getJson<GlucoseLog[]>(this.keys.glucoseLogs, []);
  }

  async addGlucoseLog(input: Omit<GlucoseLog, keyof BaseLog>): Promise<GlucoseLog> {
    const logs = await this.getGlucoseLogs();

    const log: GlucoseLog = {
      ...input,
      id: this.createId(),
      createdAt: this.now(),
      updatedAt: this.now(),
      syncStatus: 'unsynced',
    };

    await this.setJson(this.keys.glucoseLogs, [log, ...logs]);
    return log;
  }

  async getInsulinLogs(): Promise<InsulinLog[]> {
    return this.getJson<InsulinLog[]>(this.keys.insulinLogs, []);
  }

  async addInsulinLog(input: Omit<InsulinLog, keyof BaseLog>): Promise<InsulinLog> {
    const logs = await this.getInsulinLogs();

    const log: InsulinLog = {
      ...input,
      id: this.createId(),
      createdAt: this.now(),
      updatedAt: this.now(),
      syncStatus: 'unsynced',
    };

    await this.setJson(this.keys.insulinLogs, [log, ...logs]);
    return log;
  }

  async getMealLogs(): Promise<MealLog[]> {
    return this.getJson<MealLog[]>(this.keys.mealLogs, []);
  }

  async addMealLog(input: Omit<MealLog, keyof BaseLog>): Promise<MealLog> {
    const logs = await this.getMealLogs();

    const log: MealLog = {
      ...input,
      id: this.createId(),
      createdAt: this.now(),
      updatedAt: this.now(),
      syncStatus: 'unsynced',
    };

    await this.setJson(this.keys.mealLogs, [log, ...logs]);
    return log;
  }

  async getActivityLogs(): Promise<ActivityLog[]> {
    return this.getJson<ActivityLog[]>(this.keys.activityLogs, []);
  }

  async addActivityLog(input: Omit<ActivityLog, keyof BaseLog>): Promise<ActivityLog> {
    const logs = await this.getActivityLogs();

    const log: ActivityLog = {
      ...input,
      id: this.createId(),
      createdAt: this.now(),
      updatedAt: this.now(),
      syncStatus: 'unsynced',
    };

    await this.setJson(this.keys.activityLogs, [log, ...logs]);
    return log;
  }

  async getPreferences(): Promise<UserPreferences> {
    return this.getJson<UserPreferences>(this.keys.preferences, {
      welcomeCompleted: false,
      glucoseUnit: 'mmol/L',
      targetMin: 4,
      targetMax: 10,
      darkMode: false,
    });
  }

  async updatePreferences(partial: Partial<UserPreferences>): Promise<UserPreferences> {
    const current = await this.getPreferences();

    const updated: UserPreferences = {
      ...current,
      ...partial,
    };

    await this.setJson(this.keys.preferences, updated);
    return updated;
  }

  async getUnsyncedData() {
    const [glucoseLogs, insulinLogs, mealLogs, activityLogs] = await Promise.all([
      this.getGlucoseLogs(),
      this.getInsulinLogs(),
      this.getMealLogs(),
      this.getActivityLogs(),
    ]);

    return {
      glucoseLogs: glucoseLogs.filter((x) => x.syncStatus === 'unsynced'),
      insulinLogs: insulinLogs.filter((x) => x.syncStatus === 'unsynced'),
      mealLogs: mealLogs.filter((x) => x.syncStatus === 'unsynced'),
      activityLogs: activityLogs.filter((x) => x.syncStatus === 'unsynced'),
    };
  }

  async clearAllLocalData(): Promise<void> {
    await Promise.all([
      Preferences.remove({ key: this.keys.glucoseLogs }),
      Preferences.remove({ key: this.keys.insulinLogs }),
      Preferences.remove({ key: this.keys.mealLogs }),
      Preferences.remove({ key: this.keys.activityLogs }),
      Preferences.remove({ key: this.keys.preferences }),
    ]);
  }
}